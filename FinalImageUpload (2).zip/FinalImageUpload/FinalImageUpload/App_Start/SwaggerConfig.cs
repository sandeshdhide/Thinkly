using System.Web.Http;
using WebActivatorEx;
using FinalImageUpload;
using Swashbuckle.Application;
using FinalImageUpload.Controllers;


//For Register

[assembly: PreApplicationStartMethod(typeof(SwaggerConfig), "Register")]

namespace FinalImageUpload
{
    public class SwaggerConfig
    {
        public static void Register()
        {
            var thisAssembly = typeof(SwaggerConfig).Assembly;

            GlobalConfiguration.Configuration
                .EnableSwagger(c =>
                {
                    
                    c.SingleApiVersion("v1", "FinalImageUpload");

                    //I am actually facing issue here , Other Controller class can be called but the one which is required i.e AddFileParamTypes.cs is not getting populated,this will add the new param.
                    c.OperationFilter<>();
                    
                })
                .EnableSwaggerUi(c =>
                {
               
                });
        }
    }
}